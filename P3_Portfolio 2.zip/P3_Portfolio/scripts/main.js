// I used knowledge from lecture slides and the links from the assignment. Links: 
//   https://developer.mozilla.org/en-US/docs/Web/API/Window/prompt
//   https://developer.mozilla.org/en-US/docs/Web/API/Window/alert

"use strict";

function myFunction() {
  var x = document.getElementById("imageDivOne");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}

function myFunctionOne() {
  var x = document.getElementById("imageDivTwo");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}

function myFunctionTwo() {
  var x = document.getElementById("imageDivThree");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}


function myFunctionThree() {
  var x = document.getElementById("imageDivFour");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}